function [fo] = setGNM_NLBFs(fo,Stim)

g = Stim*get_k_mat(fo);
nmods = length(fo.mods); %number of modules
for imod=1:nmods; 	%for each module
    
    %update the tent basis X-axis
    n_dxs = length(fo.mods(imod).nlx);
%         fo.mods(imod).nlx = prctile(g(:,imod),linspace(0.05,99.95,n_dxs)); %equipopulated
    fo.mods(imod).nlx = linspace(prctile(g(:,imod),0.05),prctile(g(:,imod),99.95),n_dxs); %equispacing
    
    %set nearest tent basis to 0
    [~,nearest] = min(abs(fo.mods(imod).nlx));
    fo.mods(imod).nlx(nearest) = 0;
    if strcmp(fo.mods(imod).nltype,'threshlin')
        fo.mods(imod).nly = fo.mods(imod).nlx;
        fo.mods(imod).nly(1:nearest) = 0;
    end
end;

