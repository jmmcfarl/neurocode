function nim_out = NIMfit_filters(nim,Robs,Xstim,XLin,targets,silent,desired_optim_params)
%
% nim_out = NIMfit_filters(nim,Robs,Xstim,<XLin>,<targets>,<silent>,<desired_optim_params>)
%
% Optimizes the stimulus filters (plus extra linear terms if desired) for
% given upstream NLs
%
% INPUTS:
%       nim: model structure
%       Robs: binned spikes
%       Xstim: time-embedded stimulus mat
%       <XLin>: Matrix specifying additional linear predictors
%       <targets>: Vector of indices specifying which subunits to optimize.
%           (-1 = spk history filter, and -2 = extra linear filter) Default is to optimize all elements
%       <silent>: 0 to display optimization iterations, and 1 to suppress them
%       <desired_optim_params>: Struct of optimization parameters
% OUTPUTS:
%       nim_out: output model struct

%% PROCESS INPUTS
if nargin < 4
    XLin = [];
end
if nargin < 5
    targets = [];
end
if nargin < 6
    silent = 1;
end
if nargin < 7
    desired_optim_params = [];
end

%make sure Robs is a column vector
if size(Robs,2) > size(Robs,1)
    Robs = Robs';
end

[NT,filtLen] = size(Xstim); %stimulus dimensions
if filtLen ~= prod(nim.stim_params.stim_dims)
    error('Xstim dimensions dont match with stim_params')
end
nmods = length(nim.mods);

lin_dims = nim.stim_params.lin_dims;
if lin_dims ~= size(XLin,2);
    error('Mismatch between XLin and lin_dims');
end

spkhstlen = nim.spk_hist.spkhstlen;

if max(targets) > nmods %check input targets
    error('Invalid target specified');
end
if isempty(targets) %default is to optimize all model components
    targets = 1:nmods;
    if spkhstlen > 0
        targets = [targets -1]; %optimize spike hist filter
    end
    if lin_dims > 0
        targets = [targets -2]; %optimize additional linear filter
    end
end
Ntargets = sum(targets > 0); %number of targeted subunits
non_targets = setdiff([1:nmods -1 -2],targets); %elements of the model held constant

if ismember(-1,targets) && spkhstlen == 0
    error('No spk history term initialized')
end
if ismember(-2,targets) && lin_dims == 0
    error('No extra linear filter optimized')
end

%% PARSE INITIAL PARAMETERS
%compute initial fit parameters
initial_params = [];
for imod = targets(targets > 0)
    cur_kern = nim.mods(imod).filtK';
    initial_params = [initial_params; cur_kern']; %add coefs to initial param vector
end

%add in spike history coefs
if ismember(-1,targets)
    initial_params = [initial_params; nim.spk_hist.coefs];
end

%add in extra linear filter
if ismember(-2,targets)
    initial_params = [initial_params; nim.kLin];
end

initial_params(end+1) = nim.spk_NL_params(1); %add constant offset

%% COMPUTE L1 PENALTY IF APPLICABLE
lambda_L1 = zeros(size(initial_params));
for ii = 1:Ntargets
    cur_inds = (ii-1)*filtLen + (1:filtLen);
    lambda_L1(cur_inds) = nim.mods(targets(ii)).reg_params.lambda_L1';
end
lambda_L1 = lambda_L1/sum(Robs); %since we are dealing with LL/spk

%% PRECOMPUTE 'TENT-BASIS' DERIVATIVES OF UPSTREAM NLS IF NEEDED
if any(strcmp('nonpar',{nim.mods(targets(targets > 0)).NLtype}))
    for ii = 1:Ntargets
        if strcmp(nim.mods(targets(ii)).NLtype,'nonpar')
            NLx = nim.mods(targets(ii)).NLx;
            NL = nim.mods(targets(ii)).NLy;
            
            %compute derivative of non-linearity
            fpr = zeros(1,length(NLx)-1);
            for n = 1:length(fpr)
                fpr(n) = (NL(n+1)-NL(n))/(NLx(n+1)-NLx(n));
            end
            fprimes{ii} = fpr;
        else
            fprimes{ii} = [];
        end
    end
else
    fprimes = [];
end

%% CREATE SPIKE HISTORY Xmat IF NEEDED
if nim.spk_hist.spkhstlen > 0
    Xspkhst = create_spkhist_Xmat(Robs,nim.spk_hist.bin_edges);
else
    Xspkhst = [];
end

%% COMPUTE NET OUPTUT OF ALL NON-TARGET PREDICTORS
nt_gout = zeros(NT,1);
Kmat = [nim.mods(:).filtK]; %filter matrix
gint = Xstim*Kmat; %filter output of each subunit
for imod = non_targets(non_targets > 0) %for all subunits that aren't targeted
    %process subunit g's with upstream NLs
    if strcmp(nim.mods(imod).NLtype,'nonpar')
        fgint = nlin_proc_stim(gint(:,imod),nim.mods(imod).NLy,nim.mods(imod).NLx);
    elseif strcmp(nim.mods(imod).NLtype,'quad')
        fgint = gint(:,imod).^2;
    elseif strcmp(nim.mods(imod).NLtype,'lin')
        fgint = gint(:,imod);
    elseif strcmp(nim.mods(imod).NLtype,'threshlin')
        fgint = gint(:,imod);
        fgint(fgint < 0) = 0;
    else
        error('Invalid internal NL');
    end
    
    %multiply by weight and add to generating function
    nt_gout = nt_gout + fgint*nim.mods(imod).sign;
end
if ismember(-1,non_targets) && spkhstlen > 0
    nt_gout = nt_gout + Xspkhst*nim.spk_hist.coefs(:);
end
if ismember(-2,non_targets) && lin_dims > 0
    nt_gout = nt_gout + XLin*nim.kLin(:);
end

%% IDENTIFY ANY CONSTRAINTS
use_con = 0;
LB = [];UB = []; A = []; Aeq = []; %initialize constraint matrices
if spkhstlen > 0 && ismember(-1,targets) %if optimizing spk history term
    %negative constraint on spk history coefs
    if nim.spk_hist.negCon == 1
        spkhist_inds = (Ntargets*filtLen + 1):(Ntargets*filtLen + spkhstlen);
        LB = -Inf*ones(size(initial_params));
        UB = Inf*ones(size(initial_params));
        UB(spkhist_inds) = 0;
        
        use_con = 1;
    end
end
beq = zeros(size(Aeq,1),1);
b = zeros(size(A,1),1);

%% GENERATE REGULARIZATION MATRICES
L2_mats = create_L2_matrices(nim);

%%
if max(lambda_L1) > 0 && use_con == 1
    disp('Cant use L1 with constrained optimization, aborting constraints');
    use_con = 0;
end

%%
optim_params.MaxFunEvals = 100*length(initial_params);
optim_params.MaxIter = 1e3;
optim_params.Display = 'off';
if silent == 0
    optim_params.Display = 'iter';
end
if use_con == 0 %if no constraints
    
    %if using L1 reg
    if max(lambda_L1) > 0
        if exist('L1General2_PSSas','file') == 2
           optim_params.optTol = 1e-4;
           optim_params.progTol = 1e-6;
           if silent == 0
                optim_params.verbose = 1;
           else
               optim_params.verbose = 0;
           end
            [params] = L1General2_PSSas(@(K) NIMfit_filters_internal(nim, K, Robs, Xstim,Xspkhst,XLin,L2_mats,targets,nt_gout,fprimes),...
                initial_params,lambda_L1,optim_params);
%             [params] = L1General2_PSSas(@(K) NIM_fit_filters_internal(nim, K, Robs, Xstim,Xspkhst,XLin,L2_mats,targets,nt_gout,fprimes),...
%                 initial_params,lambda_L1);
        else
            error('Need to install Mark Schmidts L1 optimization toolbox for using L1');
        end
    else
        %if not using L1 reg
        if exist('minFunc','file') == 2 %try to use Mark Schmidt's optimizer
            
            %if using Mark Schmidt's optimization, some differences in option parameters
            optim_params.optTol = 1e-4;
            optim_params.progTol = 1e-6;
            optim_params.Method = 'lbfgs';
            [params] = minFunc( @(K) NIMfit_filters_internal(nim, K, Robs, Xstim,Xspkhst,XLin,L2_mats,targets,nt_gout,fprimes), initial_params, optim_params);
            
        else %if using Matlab Optim toolbox:
            %default optimization parameters
            optim_params.LargeScale = 'off';
            optim_params.TolFun = 1e-6;
            optim_params.TolX = 1e-6;
            optim_params.HessUpdate = 'bfgs';
            optim_params.GradObj = 'on';
            
            %load in specified optimization parameters
            if ~isempty(desired_optim_params)
                spec_fields = fieldnames(desired_optim_params);
                for i = 1:length(spec_fields)
                    optim_params = setfield(optim_params,spec_fields{i},getfield(desired_optim_params,spec_fields{i}));
                end
            end
            
            [params] = fminunc( @(K) NIMfit_filters_internal(nim, K, Robs, Xstim,Xspkhst,XLin,L2_mats,targets,nt_gout,fprimes), initial_params, optim_params);
        end
    end
else %if there are constraints
    
    %try to use Mark Schmidt constrained optimizer
    if exist('minConf_TMP','file') == 2 && isempty(A) && isempty(Aeq)
        %if using Mark Schmidt's optimization, some differences in option parameters
        optim_params.optTol = 1e-4;
        optim_params.progTol = 1e-6;
        [params] = minConf_TMP( @(K) NIMfit_filters_internal(nim, K, Robs, Xstim,Xspkhst,XLin,L2_mats,targets,nt_gout,fprimes),...
            initial_params, LB,UB,optim_params);
    else
        %otherwise resort to matlab's
        optim_params.GradObj = 'on';
        optim_params.LargeScale = 'off';
        optim_params.Algorithm = 'active-set';
        optim_params.optTol = 1e-4;
        optim_params.progTol = 1e-6;
        [params] = fmincon( @(K) NIMfit_filters_internal(nim, K, Robs, Xstim,Xspkhst,XLin,L2_mats,targets,nt_gout,fprimes),...
            initial_params, A,b,Aeq,beq,LB,UB,[],optim_params);
    end
end

%% PARSE MODEL FIT
nim_out = nim;
nim_out.spk_NL_params(1) = params(end);
if ismember(-1,targets)
    nim_out.spk_hist.coefs = params((Ntargets*filtLen+1):(Ntargets*filtLen+spkhstlen));
end
if ismember(-2,targets)
    nim_out.kLin = params((Ntargets*filtLen+spkhstlen+1):(Ntargets*filtLen+spkhstlen+lin_dims));
end

for ii = 1:Ntargets
    cur_kern = params((ii-1)*filtLen+(1:filtLen));
    nim_out.mods(targets(ii)).filtK = cur_kern(:);
end

[LL, penLL, ~, G, gint, fgint] = NIMmodel_eval(nim_out,Robs,Xstim,XLin);
nim_out.LL_seq = cat(1,nim_out.LL_seq,LL);
nim_out.penLL_seq = cat(1,nim_out.penLL_seq,penLL);
nim_out.opt_history = cat(1,nim_out.opt_history,{'filt'});

% Compute std dev of the output of each subunit
for n = 1:nmods
    mod_norm = std(fgint(:,n));
    nim_out.mods(n).mod_norm = mod_norm;
end

