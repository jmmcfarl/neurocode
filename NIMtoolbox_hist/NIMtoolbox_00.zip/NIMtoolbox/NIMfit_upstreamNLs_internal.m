function [LL, LLgrad] = NIMfit_upstreamNLs_internal(nim, params, Robs, Xnl, Xspkhst, XLin, L2_NLd2, targets, nt_gout)
%
% [LL, LLgrad] = NIMfit_upstreamNLs_internal(nim, params, Robs, Xnl, Xspkhst, XLin, L2_NLd2, targets, nt_gout)
%
% Internal function for computing LL and LLgradient with respect to the
% tent-basis coeffs

%% Useful params
Nmods = length(nim.mods);
Ntargets = sum(targets > 0);
lin_dims = nim.stim_params.lin_dims;
n_tbfs = length(nim.mods(targets(1)).NLx);
NT = size(Xnl,1);
spkhstlen = nim.spk_hist.spkhstlen;

%% ESTIMATE GENERATING FUNCTIONS (OVERALL AND INTERNAL)
theta = params(end); %offset 
G = theta + nt_gout;
G = G + Xnl*params(1:Ntargets*n_tbfs);

%add contribution from spike history filter
if spkhstlen > 0 && ismember(-1,targets)
   G = G + Xspkhst*params((Ntargets*n_tbfs + 1):(Ntargets*n_tbfs + spkhstlen)); 
end
%add contribution from linear filter
if lin_dims > 0 && ismember(-2,targets)
    G = G + XLin*params((Ntargets*n_tbfs+spkhstlen+1):(Ntargets*n_tbfs+spkhstlen+lin_dims));
end

%% Compute predicted firing rate
if strcmp(nim.spk_NL_type,'logexp')
    max_gbeta = 50; %to prevent numerical overflow
    bgint = G*nim.spk_NL_params(2); %g*beta
    expg = exp(bgint);
    too_large = (bgint > max_gbeta);
    r = nim.spk_NL_params(3)*log(1+expg); %alpha*log(1+exp(gbeta))
    r(too_large) = nim.spk_NL_params(3)*bgint(too_large); %log(1+exp(x)) ~ x in limit of large x
elseif strcmp(nim.spk_NL_type,'exp')
    expg = exp(G);
    r = expg;
else
    error('invalid spk nl');
end
%enforce minimum predicted firing rate to avoid nan LLs
min_pred_rate = 1e-50;
if min(r) < min_pred_rate
    r(r < min_pred_rate) = min_pred_rate; %minimum predicted rate
end

%% COMPUTE LL and LL gradient
LL = sum(Robs.* log(r) - r); %up to an overall constant

%'residual' = dLL/dr
if strcmp(nim.spk_NL_type,'logexp')
    residual = nim.spk_NL_params(3)*nim.spk_NL_params(2)*(Robs./r - 1) .* expg ./ (1+expg);
    residual(too_large) = nim.spk_NL_params(3)*nim.spk_NL_params(2)*(Robs(too_large)./r(too_large) - 1);
elseif strcmp(nim.spk_NL_type,'exp')
    residual = Robs - r;
else
    error('Unsupported spiking NL')
end

%initialize LL gradient
LLgrad = zeros(length(params),1);

LLgrad(1:Ntargets*n_tbfs) = residual'*Xnl;

% Calculate derivatives with respect to constant term (theta)
LLgrad(end) = sum(residual);

% Calculate derivative with respect to spk history filter
if spkhstlen > 0 && ismember(-1,targets)
    LLgrad((Ntargets*n_tbfs+1):(Ntargets*n_tbfs+spkhstlen)) = residual'*Xspkhst;
end
% Calculate derivative with respect to linear term
if lin_dims > 0 && ismember(-2,targets)
    LLgrad((Ntargets*n_tbfs+spkhstlen+1):(Ntargets*n_tbfs+spkhstlen+lin_dims)) = residual'*XLin;
end

%% COMPUTE L2 PENALTIES AND GRADIENTS
smooth_penalty = zeros(Ntargets,1);
LLgrad_pen = zeros(size(LLgrad));
for n = 1:Ntargets
    cur_NLy = params((n-1)*n_tbfs + (1:n_tbfs));
    if nim.mods(targets(n)).reg_params.lambda_NLd2 > 0
        smooth_penalty(n) = nim.mods(targets(n)).reg_params.lambda_NLd2*sum((L2_NLd2 * cur_NLy).^2);

        cur_grad_pen = 2*nim.mods(targets(n)).reg_params.lambda_NLd2*(L2_NLd2' * L2_NLd2 * cur_NLy);
        LLgrad_pen((n-1)*n_tbfs + (1:n_tbfs)) = cur_grad_pen;
    end
end
    
LL = LL - sum(smooth_penalty);
LLgrad = LLgrad - LLgrad_pen;

%% CONVERT TO NEGATIVE LLS AND NORMALIZE BY NSPKS
Nspks = sum(Robs);
LL = -LL/Nspks;
LLgrad = -LLgrad/Nspks;

