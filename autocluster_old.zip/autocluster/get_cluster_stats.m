function [cluster_stats] = get_cluster_stats(X,cluster_ids)
%[cluster_stats,new_cluster_ids] = get_cluster_stats(X,cluster_ids)

uspks = cluster_ids > 0;
unique_clusts = unique(cluster_ids(uspks));
n_clusts = length(unique_clusts);
for cc = 1:n_clusts
   cids = find(cluster_ids == unique_clusts(cc));
   cluster_stats.mean_spike(:,cc) = mean(X(cids,:));
   cluster_stats.std_spike(:,cc) = std(X(cids,:));
end

