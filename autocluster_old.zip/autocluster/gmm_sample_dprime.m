function [d,Dmat]  = gmm_sample_dprime(X,cluster_idx)

comp_ids = unique(cluster_idx);
n_comps = length(comp_ids);
Dmat = zeros(n_comps);
for ii = 1:(n_comps-1)
    for jj = (ii+1):n_comps
        set1 = find(cluster_idx == comp_ids(ii));
        set2 = find(cluster_idx == comp_ids(jj));
        Dmat(ii,jj) = mean(mahal(X(set1,:),X(set2,:)));
        Dmat(jj,ii) = mean(mahal(X(set2,:),X(set1,:)));
    end
end
d = mean(Dmat(Dmat > 0));