clear all
close all
addpath('~/James_scripts/autocluster/');

% target_probes = [7 9 18 33 44 49 55 58 59 74 76 89]; 95
% target_probes = [9 18 19 22 29 33 42 48 55 58 89]; 85
% target_probes = [9 12 13 18 37 42 50 72 80 86 94]; 81
% target_probes = [12 36 42 43 48 49 51 91 94]; 86

%%
Expt_name = 'G086';
cd(sprintf('/home/james/Data/bruce/%s/Spikes/',Expt_name));
Fs = 1/3.333307000208032e-05;

block_num = 12;
probe_num = 91;

data_dir = sprintf('/media/NTlab_data1/Data/bruce/%s',Expt_name);
cd(data_dir);

save_dir = sprintf('/home/james/Analysis/bruce/%s/clustering',Expt_name);
if ~exist(save_dir,'dir')
    mkdir(save_dir);
end
%% LOAD VOLTAGE SIGNAL
sfile_name = sprintf('Expt%d.p%dFullV.mat',block_num,probe_num);
add_Vmean = 0;
filt_cutoff = [100 nan];
[V,Vtime] = Load_FullV(sfile_name, add_Vmean, filt_cutoff);

%%
thresh_sign = -1;
target_Nspks = 50*range(Vtime);
spk_pts = [-12:27];

[spk_id, sig_th] = triggerSpikes(V,thresh_sign,target_Nspks);
spk_id(spk_id < spk_pts(1) | spk_id > length(V)-spk_pts(end)) = []; %get rid of spikes at the edges

allid = bsxfun(@plus,spk_id,spk_pts');
SpikeV = reshape(V(:,allid),[size(allid) size(V,1)])';
[N_spks, N_samps, N_chs] = size(SpikeV);
Spikes.times = Vtime(spk_id);
Spikes.trig_vals = V(spk_id);

 %%
% cd(sprintf('/home/james/Data/bruce/%s/Spikes/',Expt_name));
% 
% sfile_name = sprintf('nby%s.p%dt%d.mat',Expt_name,probe_num,block_num);
% load(sfile_name);
% 
% SpikeV = double(Spikes.values);
% 
% [N_spks, N_samps, N_chs] = size(SpikeV);
% Volt_conv = Spikes.maxv/Spikes.maxint*1e3; %in mV
% SpikeV = SpikeV*Volt_conv;
%%
params.outlier_thresh = 5;
params.verbose = 2;
params.use_best_only = 0;
params.cluster_bias = 0.85;

[su_inds, gmm_fit, cluster_details, spike_xy,spike_features] = autocluster_2comp(SpikeV,params);
mu_inds = setdiff(1:N_spks,su_inds);

su_spk_times = Spikes.times(su_inds);
isis = diff(su_spk_times)*1e3;
refractoriness(1) = sum(isis < 1)/length(isis)*100;
refractoriness(2) = sum(isis < 2)/length(isis)*100;
cluster_details.refract = refractoriness;

[Lratio,iso_dist] = compute_cluster_Lratio(X,cluster_inds,clust_mean,clust_Sigma)

%% CREATE SUMMARY FIGURE
fprintf('Creating summary figure\n');
cd(save_dir);

figure('visible','off');

% DENSITY PLOT IN XY SPACE
subplot(2,3,1);
[handles, details] = DensityPlot_jmm(spike_xy(:,1),spike_xy(:,2),'sqrtsc','ynormal','sd',[1 1]);

% SCATTERPLOT IN XY SPACE
subplot(2,3,2); hold on
plot(spike_xy(mu_inds,1),spike_xy(mu_inds,2),'k.');
plot(spike_xy(su_inds,1),spike_xy(su_inds,2),'r.');
for ii = 1:length(cluster_labels)
    if cluster_labels(ii) == 1
        h1 = plot_gaussian_2d(gmm_xyMeans(ii,:)',squeeze(gmm_xySigma(:,:,ii)),[1 2],'g',2);
    else
        h1 = plot_gaussian_2d(gmm_xyMeans(ii,:)',squeeze(gmm_xySigma(:,:,ii)),[1 2],'b',2);
    end
end
title(sprintf('Dprime: %.3f  LL: %.1f',cluster_details.dprime,cluster_details.LL));

% AVG WAVEFORMS
subplot(2,3,3); hold on
plot((1:N_samps)/Fs*1e3,SpikeV(mu_inds,:),'k','linewidth',0.01);
plot((1:N_samps)/Fs*1e3,SpikeV(su_inds,:),'r','linewidth',0.01);
errorbar((1:N_samps)/Fs*1e3,cluster_details.mean_spike(:,1),cluster_details.std_spike(:,1),'g','linewidth',1.5)
errorbar((1:N_samps)/Fs*1e3,cluster_details.mean_spike(:,2),cluster_details.std_spike(:,2),'b','linewidth',1.5)
xlabel('Time (ms)','fontsize',14);
ylabel('Amplitude (mV)','fontsize',14);
xlim([1 N_samps]/Fs*1e3);

% ISI DIST
subplot(2,3,4); hold on
isi_bins = [logspace(log10(5e-4),log10(1),100)]*1e3;
isi_hist = histc(isis,isi_bins);
isi_hist = isi_hist/sum(isi_hist);
stairs(isi_bins,isi_hist)
set(gca,'xscale','log');
yl = ylim();
line([2 2],yl,'color','r','linestyle','--');
line([1 1],yl,'color','r');
xlim([0.5 1000]);
xlabel('ISI (ms)','fontsize',14);
ylabel('Relative frequency','fontsize',14);
title(sprintf('%.2f - %.2f refractoriness',refractoriness(1),refractoriness(2)),'fontsize',20);

% Time v X plot
subplot(2,3,5); hold on
plot(Spikes.times(mu_inds),spike_xy(mu_inds,1),'k.')
plot(Spikes.times(su_inds),spike_xy(su_inds,1),'r.')
hold on
plot(Spikes.times(mu_inds),smooth(spike_xy(mu_inds,1),30,'rlowess'),'g','linewidth',2)
plot(Spikes.times(su_inds),smooth(spike_xy(su_inds,1),30,'rlowess'),'b','linewidth',2)
xlabel('Spike time (s)','fontsize',14)
ylabel('Feature projection','fontsize',14);
xlim(Vtime([1 end]));

% Trigger amp dist
trig_ax = linspace(min(Spikes.trig_vals),max(Spikes.trig_vals),200);
su_trig_hist = histc(Spikes.trig_vals(su_inds),trig_ax)/length(su_inds);
mu_trig_hist = histc(Spikes.trig_vals(mu_inds),trig_ax)/length(mu_inds);
subplot(2,3,6) ;hold on
stairs(trig_ax,su_trig_hist,'r','linewidth',1);
stairs(trig_ax,mu_trig_hist,'k','linewidth',1);
yl = ylim();
line([sig_th sig_th]*thresh_sign,yl,'color','b','linewidth',2);
xlabel('Trigger voltage','fontsize',14);
ylabel('Relative frequency','fontsize',14);


fillPage(gcf,'papersize',[14 8]);
fname = sprintf('Expt%d_probe%d_cluster',block_num,probe_num);
print(fname,'-dpng','-r100');
close 
