function [cluster_labels, cluster_stats] = relabel_clusters(SpikeV,cluster_idx_in,cluster_labels)

cluster_idx_out = cluster_idx_in;
uspks = cluster_idx_in > 0;
unique_cids = unique(cluster_idx_in(uspks));
for ii = 1:length(unique_cids)
    cluster_idx_out(cluster_idx_in == unique_cids(ii)) = cluster_labels(ii); 
end

[cluster_stats] = get_cluster_stats(SpikeV,cluster_idx_out);
uspks = find(cluster_idx_out > 0);

%if the cluster IDS are asked for, relabel clusters based on peak amplitude
max_amps = max(abs(cluster_stats.mean_spike));
[~,label_order] = sort(max_amps);

cluster_idx_out(uspks) = label_order(cluster_idx_out(uspks));

cluster_labels = label_order(cluster_labels);

if length(cluster_labels) > 2
    [orig_cluster_stats] = get_cluster_stats(SpikeV,cluster_idx_in);
    orig_max_amps = max(abs(orig_cluster_stats.mean_spike));
    for ii = 2:max(cluster_labels)
        cur_set = find(cluster_labels == ii);
        if length(cur_set) > 1
            smaller = cur_set(orig_max_amps(cur_set) ~= max(orig_max_amps(cur_set)));
            cluster_labels(smaller) = 1;
        end
    end
end

cluster_stats.mean_spike = cluster_stats.mean_spike(:,label_order);
cluster_stats.std_spike = cluster_stats.std_spike(:,label_order);