function Spikes = getSpikeSnippets(V,Vtime,spk_id,spk_pts)
% Spikes = getSpikeSnippets(V,spk_id,spk_pts)

allid = bsxfun(@plus,spk_id,spk_pts');
Spikes.V = reshape(V(:,allid),[size(allid) size(V,1)])';
Spikes.times = Vtime(spk_id);
Spikes.trig_vals = V(spk_id);
