clear all
close all
addpath('~/James_scripts/autocluster/');
%%
Expt_name = 'G086';
cd(sprintf('/home/james/Data/bruce/%s/Spikes/',Expt_name));

block_num = 12;
probe_num = 94;
% target_probes = [7 9 18 33 44 49 55 58 59 74 76 89]; 95
% target_probes = [9 18 19 22 29 33 42 48 55 58 89]; 85
% target_probes = [9 12 13 18 37 42 50 72 80 86 94]; 81
% target_probes = [12 36 42 43 48 49 51 91 94]; 86

sfile_name = sprintf('nby%s.p%dt%d.mat',Expt_name,probe_num,block_num);
load(sfile_name);

SpikeV = double(Spikes.values);
[N_spks,D] = size(SpikeV);

outlier_thresh = 5;

%% compute pcs
[pc_coeffs,pc_scores] = princomp(SpikeV);

%% INITIAL CLUSTERING IN PC SPACE
n_pcs = 4;
n_clusts = 2;
[GMM_obj{1}, distance(1),all_clust_idx(:,1),all_clust_labels(:,1),cluster_stats] = GMM_fit(SpikeV,pc_scores(:,1:n_pcs),n_clusts,outlier_thresh,n_clusts);
LL(1) = GMM_obj{1}.NlogL;
cluster_means = cluster_stats.mean_spike;
[~,best_ch] = max(max(abs(cluster_means)));
spk_wvfrm = cluster_means(:,best_ch);
[~,minloc] = min(spk_wvfrm);
[~,maxloc] = max(spk_wvfrm);
first_peak = min([minloc maxloc]);
second_peak = max([minloc maxloc]);
fprintf('PC d-prime: %.4f\n',distance(1));
%% INITIAL CLUSTERING IN VOLTAGE SPACE
% use_tdims = [6 13 16 20];
use_tdims = [first_peak second_peak round((second_peak+first_peak)/2) second_peak + round((second_peak-first_peak)/2)];
use_tdims(use_tdims > D) = [];
n_clusts = 2;
[GMM_obj{2}, distance(2),all_clust_idx(:,2),all_clust_labels(:,2)] = GMM_fit(SpikeV,SpikeV(:,use_tdims),n_clusts,outlier_thresh,n_clusts);
LL(2) = GMM_obj{2}.NlogL;
fprintf('Voltage d-prime: %.4f\n',distance(2));

%%
close all
[d, best] = max(distance);
init_clust_idx = all_clust_idx(:,best);
init_distance = distance(best);
init_cluster_labels = 1:n_clusts;
[init_cluster_labels,cluster_stats] = relabel_clusters(SpikeV,init_clust_idx,init_cluster_labels);
if best == 1
    [xy] = Project_GMMfeatures(pc_scores(:,1:n_pcs), GMM_obj{1},init_cluster_labels);
elseif best == 2
    [xy] = Project_GMMfeatures(SpikeV(:,use_tdims), GMM_obj{2},init_cluster_labels);
end
[handles, details] = DensityPlot_jmm(xy(:,1),xy(:,2),'sqrtsc','ynormal','sd',[1 1]);
su_inds = find(ismember(init_clust_idx,find(init_cluster_labels == 2)));
mu_inds = find(ismember(init_clust_idx,find(init_cluster_labels == 1)));
figure
plot(xy(mu_inds,1),xy(mu_inds,2),'k.');
hold on
plot(xy(su_inds,1),xy(su_inds,2),'r.');
figure; hold on
errorbar(1:40,cluster_stats.mean_spike(:,1),cluster_stats.std_spike(:,1),'k')
errorbar(1:40,cluster_stats.mean_spike(:,2),cluster_stats.std_spike(:,2),'r')


% avg_su_x1 = mean(xy(su_inds,1));
% avg_mu_x1 = mean(xy(mu_inds,1));
% hard_thresh_cidx = ones(N_spks,1);
% hard_thresh_cidx(xy(:,1) > avg_su_x1) = 2;
% [init_cluster_labels,cluster_stats] = relabel_clusters(SpikeV,hard_thresh_cidx,init_cluster_labels);
% su_inds = find(ismember(hard_thresh_cidx,find(init_cluster_labels == 2)));
% mu_inds = find(ismember(hard_thresh_cidx,find(init_cluster_labels == 1)));
% figure
% plot(xy(mu_inds,1),xy(mu_inds,2),'k.');
% hold on
% plot(xy(su_inds,1),xy(su_inds,2),'r.');
% figure; hold on
% errorbar(1:40,cluster_stats.mean_spike(:,1),cluster_stats.std_spike(:,1),'k')
% errorbar(1:40,cluster_stats.mean_spike(:,2),cluster_stats.std_spike(:,2),'r')

%%
close all
params.verbose = 2;
params.outlier_thresh = 5;
params.use_best_only = 0;
[template_GMM,template_clust_idx,template_cluster_labels,cluster_stats,template_distance,use_it,template_scores] = ...
    iterative_template_GMM(SpikeV,init_clust_idx,init_distance,params);
features = template_scores;
if use_it == 1
    template_GMM = GMM_obj{best};
    template_cluster_labels = all_clust_labels(:,best);
    if best == 1
        features = pc_scores(:,1:n_pcs);
    elseif best == 2
        features = SpikeV(:,use_tdims);
    end
end
% [template_clust_idx,cluster_labels] = relabel_clusters(SpikeV,template_clust_idx);

bias = 0.85;
rtemplate_clust_idx = biased_gmm_clustering(features,template_GMM,bias,template_cluster_labels,outlier_thresh);


[xy] = Project_GMMfeatures(features, template_GMM,template_cluster_labels);

% [handles, details] = DensityPlot_jmm(xy(:,1),xy(:,2),'sqrtsc','ynormal');
[handles, details] = DensityPlot_jmm(xy(:,1),xy(:,2),'sqrtsc','ynormal','sd',[1 1]);
su_inds = find(ismember(rtemplate_clust_idx,find(template_cluster_labels == 2)));
mu_inds = find(ismember(rtemplate_clust_idx,find(template_cluster_labels == 1)));
% su_inds = find(ismember(template_clust_idx,find(template_cluster_labels == 2)));
% mu_inds = find(ismember(template_clust_idx,find(template_cluster_labels == 1)));
figure
plot(xy(mu_inds,1),xy(mu_inds,2),'k.');
hold on
plot(xy(su_inds,1),xy(su_inds,2),'r.');


figure; hold on
errorbar(1:40,cluster_stats.mean_spike(:,1),cluster_stats.std_spike(:,1),'k')
errorbar(1:40,cluster_stats.mean_spike(:,2),cluster_stats.std_spike(:,2),'r')


