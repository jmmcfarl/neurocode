function [L,iso_distance] = compute_cluster_Lratio(X,gmm_fit,cluster_idx,cluster_labels)

su_ind = find(cluster_labels == 2);
clust_mean = gmm_fit.mu(su_ind,:);
clust_Sigma = squeeze(gmm_fit.Sigma(:,:,su_ind));

mean_seps = bsxfun(@minus,X,clust_mean);
D = sum((mean_seps/clust_Sigma) .* mean_seps,2);

df = size(X,2);
clust_spikes = cluster_idx == su_ind;
non_clust_spikes = cluster_idx ~= su_ind;
L = sum(1 - chi2cdf(D(non_clust_spikes),df));

if sum(clust_spikes) < sum(non_clust_spikes)
    D = sort(D);
    iso_distance = sqrt(D(sum(clust_spikes)));
else
    iso_distance = nan;
end