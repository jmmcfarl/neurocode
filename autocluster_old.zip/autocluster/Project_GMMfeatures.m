function [xy,pvec] = Project_GMMfeatures(features, gmm_obj, cluster_labels)

[n_spks,D] = size(features);
n_unique_clusters = length(unique(cluster_labels));
GMM_mus = gmm_obj.mu;
GMM_sigmas = gmm_obj.Sigma;
if n_unique_clusters < size(GMM_mus,1) %if there are multiple components per cluster
    weights = gmm_obj.PComponents;
    real_GMM_mus = nan(n_unique_clusters,D);
    real_GMM_sigmas = nan(D,D,n_unique_clusters);
    for ii = 1:n_unique_clusters
       real_GMM_mus(ii,:) = mean(GMM_mus(cluster_labels == ii,:),1);
       real_GMM_sigmas(:,:,ii) = mean(GMM_sigmas(:,:,cluster_labels == ii),3);
    end
    GMM_mus = real_GMM_mus;
    GMM_sigmas = real_GMM_sigmas;
end
%% gets 1xd best separating vector based on component means
if size(GMM_mus,1) > 2
    pvec(:,1) = range(GMM_mus);
else
    md = diff(GMM_mus);
    S = squeeze(sum(GMM_sigmas,3));
    pvec(:,1) = md/S;
end
pvec(:,1) = pvec(:,1)/norm(pvec(:,1));

%for the second dimension pick from the first two PCs the one that is least
%correlated with the first dimension
[V,D] = eig(cov(features));
other_w = V(:,end-1:end);
cc = corr(other_w,pvec);
[~,least] = min(abs(cc));
other_w = other_w(:,least);
pvec(:,2) = other_w - dot(pvec(:,1),other_w);
pvec(:,2) = pvec(:,2)/norm(pvec(:,2));

%%
xy = features*pvec;


