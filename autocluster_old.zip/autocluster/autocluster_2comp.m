function [su_inds, gmm_fit, cluster_details, spike_xy, spike_features] = autocluster_2comp(SpikeV,params)
% [cluster_idx, gmm_fit, cluster_labels, features, cluster_details] = autocluster_2comp(SpikeV,params)
%

%%

if nargin < 2 || isempty(params)
    params = struct();
end
if ~isfield(params,'outlier_thresh')
    params.outlier_thresh = 5; %threshold mahalanobis distance to treat points as outliers
end
if ~isfield(params,'verbose')
    params.verbose = 0; %controls level of print detail
end
if ~isfield(params,'use_best_only')
    params.use_best_only = 0; %use only the best cluster waveform as template?
end
if ~isfield(params,'cluster_bias')
    params.cluster_bias = 0.5;  %posterior probability threshold for classifying as SU
end


%% compute pcs
[N_spks,D] = size(SpikeV);
[pc_coeffs,pc_scores] = princomp(SpikeV);

%% INITIAL CLUSTERING IN PC SPACE
n_pcs = 4;
n_clusts = 2;
[GMM_obj{1}, distance(1),all_clust_idx(:,1),all_clust_labels(:,1),cluster_stats] = ...
    GMM_fit(SpikeV,pc_scores(:,1:n_pcs),n_clusts,params.outlier_thresh,n_clusts);
LL(1) = GMM_obj{1}.NlogL;

%find peak and valley locations for the best cluster
cluster_means = cluster_stats.mean_spike;
[~,best_ch] = max(max(abs(cluster_means)));
spk_wvfrm = cluster_means(:,best_ch);
[~,minloc] = min(spk_wvfrm);
[~,maxloc] = max(spk_wvfrm);
first_peak = min([minloc maxloc]);
second_peak = max([minloc maxloc]);
if params.verbose > 0
    fprintf('PC d-prime: %.4f\n',distance(1));
end

%% INITIAL CLUSTERING IN VOLTAGE SPACE
% use_tdims = [6 13 16 20];
use_tdims = [first_peak second_peak round((second_peak+first_peak)/2) second_peak + round((second_peak-first_peak)/2)];
use_tdims(use_tdims > D) = [];
n_clusts = 2;
[GMM_obj{2}, distance(2),all_clust_idx(:,2),all_clust_labels(:,2)] = ...
    GMM_fit(SpikeV,SpikeV(:,use_tdims),n_clusts,params.outlier_thresh,n_clusts);
LL(2) = GMM_obj{2}.NlogL;
if params.verbose > 0
    fprintf('Voltage d-prime: %.4f\n',distance(2));
end
%% CHOOSE BEST INITIAL CLUSTERING
[d, best] = max(distance); %best clustering so far

init_clust_idx = all_clust_idx(:,best);
init_distance = distance(best);
init_cluster_labels = 1:n_clusts;
[init_cluster_labels,cluster_stats] = relabel_clusters(SpikeV,init_clust_idx,init_cluster_labels);

if params.verbose > 0
   if best == 1
      fprintf('Using PC initial clustering\n'); 
   elseif best == 2
      fprintf('Using Voltage initial clustering\n'); 
   end
end

%%
[template_GMM,template_clust_idx,template_cluster_labels,cluster_stats,template_distance,used_it,template_scores] = ...
    iterative_template_GMM(SpikeV,init_clust_idx,init_distance,params);
spike_features = template_scores;

%if template clustering is better than the initial clustering use it
if template_distance > init_distance
    if params.verbose > 0
       fprintf('Using template clustering, iteration %d\n',used_it); 
    end
    gmm_fit = template_GMM;
    spike_features = template_scores;
    cluster_labels = template_cluster_labels;
    cluster_idx = template_clust_idx;
else
    gmm_fit = GMM_obj{best};
    cluster_labels = init_cluster_labels;
    cluster_idx = init_clust_idx;    
    if best == 1
        spike_features = pc_scores(:,1:n_pcs);
        used_it = -1;
    elseif best == 2
        spike_features = SpikeV(:,use_tdims);
        used_it = -2;
    end
end
cluster_details.LL = gmm_fit.NlogL;
cluster_details.dprime = gmm_dprime(gmm_fit,cluster_labels);
cluster_details.used_it = used_it;

%% IMPLEMENT BIASED CLUSTERING
if params.cluster_bias ~= 0.5
    if params.verbose > 0
       fprintf('Performing biased clustering\n'); 
    end
    cluster_idx = biased_gmm_clustering(spike_features,gmm_fit,params.cluster_bias,cluster_labels,params.outlier_thresh);
end

%%
[cluster_labels, cluster_stats] = relabel_clusters(SpikeV,cluster_idx,cluster_labels);
cluster_details.mean_spike = cluster_stats.mean_spike;
cluster_details.std_spike = cluster_stats.std_spike;
su_inds = find(ismember(cluster_idx,find(cluster_labels == 2)));

cluster_details.cluster_idx = cluster_idx;
cluster_details.cluster_labels = cluster_labels;
%%
[spike_xy,xyproj_mat] = Project_GMMfeatures(spike_features, gmm_fit,cluster_labels);
if mean(spike_xy(su_inds,1)) < 0
    spike_xy(:,1) = -spike_xy(:,1);
    xyproj_mat(:,1) = -xyproj_mat(:,1);
end

cluster_details.xy_projmat = xyproj_mat;

%compute GMM model parameters projected into XY space
gmm_xyMeans = gmm_fit.mu*xyproj_mat;
for ii = 1:size(gmm_fit.Sigma,3)
gmm_xySigma(:,:,ii) = xyproj_mat' * squeeze(gmm_fit.Sigma(:,:,ii)) * xyproj_mat;
end
cluster_details.gmm_xyMeans = gmm_xyMeans;
cluster_details.gmm_xySigma = gmm_xySigma;


