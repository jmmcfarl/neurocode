function [gmm_obj, gmm_distance, clust_ids, cluster_labels, cluster_stats, outliers] = ...
    GMM_fit(SpikeV, X, n_clusts, outlier_thresh,max_clusters,init_cluster_idx,init_cluster_labels)


if n_clusts > 3
    fprintf('Not supported\n');
    G = [];
    D = [];
    all = [];
    return;
end
if nargin < 4
    outlier_thresh = nan;
end
if nargin < 5
    max_clusters = 3;
end
if nargin < 6
    init_cluster_idx = [];
end
if ~isempty(init_cluster_idx)
    use_init = true;
else
    use_init = false;
end

if use_init %if an initial clustering is specified, just use this
    n_clusts = length(init_cluster_labels);
    init_cluster_idx(init_cluster_idx < 1) = 1;
    try
        Gs{1} = gmdistribution.fit(X,n_clusts,'Start',init_cluster_idx);
        ds(1) = gmm_dprime(Gs{1});
        clust_labels{1} = init_cluster_labels;
        clust_idx = cluster(Gs{1},X);
        [L(1),iso_distance(1)] = compute_cluster_Lratio(X,Gs{1},clust_idx,clust_labels{1});
        fail(1) = 0;
    catch
        Gs{1} = [];
        ds(1) = nan;
        L(1) = nan;
        iso_distance(1) = nan;
        fail(1) = 1;
    end
else
    %% TRY FITTING WITH RANDOM INITS
    n_iters = 5000;
    try
        Gs{1} = gmdistribution.fit(X,n_clusts,'Options',statset('MaxIter',n_iters));
        ds(1) = gmm_dprime(Gs{1});
        clust_labels{1} = 1:n_clusts;
        clust_idx = cluster(Gs{1},X);
        [L(1),iso_distance(1)] = compute_cluster_Lratio(X,Gs{1},clust_idx,clust_labels{1});
        fail(1) = 0;
    catch
        Gs{1} = [];
        ds(1) = nan;
        L(1) = nan;
        iso_distance(1) = nan;
        fail(1) = 1;        
    end
    %% TRY FITTING WITH PREDEFINED INIT
    %sets the initial component means to be separated along the first PC. If 3
    %clusters seperates the 3rd along the 2nd PC. Initializes the component
    %covariances to all be some fraction of the full covariance of X
    
    if size(X,2) > 1
        C = cov(X);
        [E,V] = eig(C);
        pc = E(:,end); %first PC
        pcb = E(:,end-1); %second pc
        pc = pc./max(abs(pc)); %normalize to have max 1
        pcb = pcb./max(abs(pcb));
        for j = 1:size(X,2)
            S.mu(1,j) = mean(X(:,j)) + pc(j);
            S.mu(2,j) = mean(X(:,j)) - pc(j);
            if n_clusts == 3
                S.mu(3,j) = mean(X(:,j)) + pcb(j);
            end
        end
        for j = 1:n_clusts
            S.Sigma(:,:,j) = C./sqrt(2);
        end
        
        try
            Gs{2} = gmdistribution.fit(X,n_clusts,'Start',S);
            ds(2) = gmm_dprime(Gs{2});
            clust_labels{2} = 1:n_clusts;
            clust_idx = cluster(Gs{2},X);
            [L(2),iso_distance(2)] = compute_cluster_Lratio(X,Gs{2},clust_idx,clust_labels{2});
            fail(2) = 0;
        catch
            Gs{2} = S;
            ds(2) = nan;
            L(2) = nan;
            iso_distance(2) = nan;
            fail(2) = 1;           
        end
    end
    %% TRY FITTING model with an extra component
    if n_clusts + 1 <= max_clusters
        
        [~,cur_best] = max(ds);
        clust_idx = cluster(Gs{cur_best},X);
        cluster_labels = 1:n_clusts;
        [cluster_labels,cluster_stats] = relabel_clusters(SpikeV,clust_idx,cluster_labels);
        S.mu = Gs{cur_best}.mu;
        S.Sigma = Gs{cur_best}.Sigma;
        S.Sigma(:,:,3) = S.Sigma(:,:,cluster_labels==1);
        sep_vec = diff(S.mu);
        if cluster_labels(1) == 2
            sep_vec = -sep_vec;
        end
        S.mu(3,:) = S.mu(cluster_labels==1,:) - 0.5*sep_vec;
        S.mu(cluster_labels==2,:) = S.mu(cluster_labels==2,:) + 0.5*sep_vec;
        
        try
            Gs{3} = gmdistribution.fit(X,n_clusts+1,'Start',S);
            if min(Gs{3}.PComponents) < 0.1
                Gs{3} = gmdistribution.fit(X,n_clusts+1,'Options',statset('MaxIter',1000));
            end
            fail(3) = 0;
        catch
            try
                Gs{3} = gmdistribution.fit(X,n_clusts+1,'Options',statset('MaxIter',1000));                
            catch
                Gs{3} = [];
                fail(3) = 1;
            end
        end

        if fail(3) == 0
        cur_ds = gmm_dprime(Gs{3});
        %merge too closest clusters
        [d,Dmat]  = gmm_dprime(Gs{3});
        [ii,jj] = meshgrid(1:(n_clusts+1),1:(n_clusts+1));
        Dmat(Dmat == 0) = nan;
        [~,minloc] = min(Dmat(:));
        to_merge = [ii(minloc) jj(minloc)];
        clust_labels{3} = 1:(n_clusts+1);
        non_merged = setdiff(clust_labels{3},to_merge);
        clust_labels{3}(to_merge) = 1;
        clust_labels{3}(non_merged) = (2:n_clusts);
        [~,~,clust_labels{3}] = unique(clust_labels{3});
        ds(3) = gmm_dprime(Gs{3},clust_labels{3});
        clust_idx = cluster(Gs{3},X);
        [L(3),iso_distance(3)] = compute_cluster_Lratio(X,Gs{3},clust_idx,clust_labels{3});
        
        %when using multiple gaussians to model noise background, require
        %that Lratio is better than simpler models, in addition to the
        %Dprime being better. So, if the Lratio isn't better, just kill the
        %model
        if L(3) > min(L(1:2))
            ds(3) = 0;
        end
        
        else
           ds(3) = nan;
           iso_distance(3) = nan;
           L(3) = nan;
        end
    end
end
%% PICK BEST FIT
[gmm_distance,best] = max(ds);
gmm_obj = Gs{best};
cluster_labels = clust_labels{best};
%% CHECK FOR OUTLIERS
if ~isnan(outlier_thresh)
    use_nclusts = size(gmm_obj.mu,1);
    [idx,nlogl,P,logpdf,M] = cluster(gmm_obj,X);
    min_mah_dists = sqrt(min(M,[],2));
    outliers = find(min_mah_dists > outlier_thresh);
    use_idx = setdiff(1:size(X,1),outliers);
    S.mu = gmm_obj.mu; S.Sigma = gmm_obj.Sigma;
    gmm_obj = gmdistribution.fit(X(use_idx,:),use_nclusts,'Start',S);
    gmm_distance = gmm_dprime(gmm_obj,cluster_labels);
    clust_ids = cluster(gmm_obj,X);
    clust_ids(outliers) = -1;
else
    clust_ids = cluster(gmm_obj,X);
    outliers = [];
end

[cluster_labels,cluster_stats] = relabel_clusters(SpikeV,clust_ids,cluster_labels);
