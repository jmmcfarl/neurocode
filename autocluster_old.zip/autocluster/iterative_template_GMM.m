function [GMM_obj,clust_idx,clust_labels,cluster_stats,distance,used_it,template_scores] = iterative_template_GMM(Spikes,init_clust_idx,init_distance,params)
% [GMM_obj,clust_idx,distance] = iterative_template_GMM(Spikes,init_clust_idx,t_derivs,use_ms,verbose)

%%
if nargin < 3
    init_distance = Inf;
end
if nargin < 4
    params = struct();
end
if ~isfield(params,'max_iter')
    params.max_iter = 10;
end
if ~isfield(params,'deriv_types')
   params.deriv_types = [0 1]; %default use both 0th and 1st derivative templates
end
if ~isfield(params,'clust_eps')
    params.clust_eps = 0.01;
end
if ~isfield(params,'use_ms')
    params.use_ms = 1; %default use mean-subtraction
end
if ~isfield(params,'outlier_thresh')
    params.outlier_thresh = nan;
end
if ~isfield(params,'verbose')
    params.verbose = 0;
end
if ~isfield(params,'use_best_only')
    params.use_best_only = 0;
end
if any(params.deriv_types > 1)
    error('Only first derivative supported');
end
warning('off','stats:gmdistribution:FailedToConverge');
warning('off','stats:gmdistribution:MaxIterations');

[N_spks,D,N_chs] = size(Spikes);
n_clusters = length(unique(init_clust_idx(init_clust_idx > 0)));
%% DO initial template GMM 
if params.verbose > 0
    fprintf('Fitting GMM to initial template scores\n');
end
cluster_stats = get_cluster_stats(Spikes,init_clust_idx); %initial cluster stats
cluster_means = cluster_stats.mean_spike;

[~,best_cluster] = max(max(abs(cluster_means)));
if params.use_best_only
   cluster_means = cluster_means(:,best_cluster); 
   n_used_clusters = 1;
else
    n_used_clusters = n_clusters;
end

n_templates = length(params.deriv_types)*N_chs*n_used_clusters; %one template for each derivative type, channel, and cluster
templates = zeros(D,n_templates);
channels = zeros(n_templates,1);
t_derivs = zeros(n_templates,1);
cnt = 1;
if any(params.deriv_types == 0)
    for cc = 1:N_chs
        templates(:,cnt:(cnt+n_used_clusters-1)) = cluster_means;
        channels(cnt:(cnt+n_used_clusters-1)) = cc;
        t_derivs(cnt:(cnt+n_used_clusters-1)) = 0;
        cnt = cnt + n_used_clusters;
    end
end
if any(params.deriv_types == 1)
    for cc = 1:N_chs
        templates(2:end,cnt:(cnt+n_used_clusters-1)) = diff(cluster_means);
        channels(cnt:(cnt+n_used_clusters-1)) = cc;
        t_derivs(cnt:(cnt+n_used_clusters-1)) = 1;
        cnt = cnt + n_used_clusters;
    end
end


[template_scores] = get_template_scores(Spikes,templates,channels,t_derivs,ones(n_templates,1)*params.use_ms);

max_clusts = 3;
[GMM_obj{1}, distance(1),all_clust_idx(:,1), all_clust_labels(:,1), cluster_stats] = GMM_fit(Spikes,template_scores,n_clusters,params.outlier_thresh,max_clusts);

clust_change(1) = sum(all_clust_idx(:,1) ~= init_clust_idx)/N_spks;
if params.verbose > 1
    fprintf('Iteration 1, clust_change: %.4f   GMM d-prime: %.4f\n',clust_change(end),distance(end));
end

%%
it_cnt = 2;
if distance(1) > init_distance
    better_clust = true;
else
    fprintf('Template clustering worse than initial, keeping initial\n');
    clust_idx = init_clust_idx(:,1);
    clust_labels = all_clust_labels(:,1);
    GMM_obj = GMM_obj{1};
    used_it = 0;
    return;
end
while clust_change(end) > params.clust_eps && better_clust
    
    cluster_means = cluster_stats.mean_spike;
    [~,best_cluster] = max(max(abs(cluster_means)));
    if params.use_best_only
        cluster_means = cluster_means(:,best_cluster);
        n_used_clusters = 1;
    else
        n_used_clusters = n_clusters;
    end
    cnt = 1;
    if any(params.deriv_types == 0)
        for cc = 1:N_chs
            templates(:,cnt:(cnt+n_used_clusters-1)) = cluster_means;
            cnt = cnt + n_used_clusters;
        end
    end
    if any(params.deriv_types == 1)
        for cc = 1:N_chs
            templates(2:end,cnt:(cnt+n_used_clusters-1)) = diff(cluster_means);
            cnt = cnt + n_used_clusters;
        end
    end
    prev_template_scores = template_scores;
    [template_scores] = get_template_scores(Spikes,templates,channels,t_derivs,ones(n_templates,1)*params.use_ms);
    [GMM_obj{it_cnt}, distance(it_cnt),all_clust_idx(:,it_cnt), all_clust_labels(:,it_cnt), cluster_stats] = ...
        GMM_fit(Spikes,template_scores,n_clusters,params.outlier_thresh,0,all_clust_idx(:,it_cnt-1),all_clust_labels(:,it_cnt-1));
    
    clust_change(it_cnt) = sum(all_clust_idx(:,it_cnt) ~= all_clust_idx(:,it_cnt-1))/N_spks;
    if distance(it_cnt) <= distance(it_cnt - 1)
        better_clust = false;
    end
    if params.verbose > 1
        fprintf('Iteration %d, clust_change: %.4f   GMM d-prime: %.4f\n',it_cnt,clust_change(end),distance(end));
    end
    it_cnt = it_cnt + 1;
end

%%
if better_clust
    GMM_obj = GMM_obj{end};
    clust_idx = all_clust_idx(:,end);
    clust_labels = all_clust_labels(:,end);
    distance = distance(end);
    used_it = it_cnt;
else
    GMM_obj = GMM_obj{end-1};
    template_scores = prev_template_scores;
    clust_idx = all_clust_idx(:,end-1);
    clust_labels = all_clust_labels(:,end-1);
    distance = distance(end-1);
    used_it = it_cnt-1;
end
