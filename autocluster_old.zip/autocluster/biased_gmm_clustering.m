function cluster_idx = biased_gmm_clustering(features,gmm_fit,bias,cluster_labels,outlier_thresh)
% cluster_idx = biased_gmm_clustering(features,gmm_fit,bias,cluster_labels,outlier_thresh)
% GMM clustering that sets all points with posterior probabilities of
% greater than 1-bias to the 'background' cluster (cluster_labels==1)
%%
if nargin < 5
    outlier_thresh = nan;
end
[cluster_idx,~,P,~,M] = cluster(gmm_fit,features);
if ~isnan(outlier_thresh)
    min_mah_dists = sqrt(min(M,[],2));
    outliers = min_mah_dists > outlier_thresh;
    cluster_idx(outliers) = -1;
end

% uspks = cluster_idx > 0;
% cluster_idx(uspks) = cluster_labels(cluster_idx(uspks));

back_set = find(cluster_labels==1);
back_P = P(:,back_set);
total_back_P = sum(back_P,2);
[~,best_back] = max(back_P,[],2);
set_to_back = total_back_P >= (1-bias);
cluster_idx(set_to_back) = back_set(best_back(set_to_back));


